#include <LPC17xx.h>
#include "uart_polling.h"
#include "../RTX_CM3/INC/RTL.h" /* modified RTL.h file. NOT the default one! */
#include <stdio.h>
#include <string.h>
#include <math.h>




int p, c; //number of values produced, consumed
const int P = 3, C = 1, N = 398, B = 8;

U32 ta, tb;

typedef struct {
	int buf[B];
	int pIndex;
	int cIndex;
} boundedBuffer;

boundedBuffer buffer;

OS_SEM data, lock, prod, con, access;

OS_MUT print;




extern void os_idle_demon(void);
__task void producer(void* arg);
__task void consumer(void* arg);

void insert(int payload);
int retrieve(void);


// Producer Task
__task void producer (void* arg) {

	int id = (int)arg;
	int payload = id;

	while (1) {
		

		os_sem_wait(&prod, 0xFFFF);
		
		if (p >= (N-1)) {
			os_sem_send(&prod);
			break;
		}
		
		p++;
		
		os_sem_send(&prod);

		insert(payload);
		//debug only
// 		os_mut_wait(&print, 0xFFFF);
// 		printf("p%d %d %d\n", id, p, payload);
// 		os_mut_release(&print);

		// Produce only specific numbers 
		payload += P;
		
		
	}
	os_tsk_delete_self ();


}

// Consumer task
__task void consumer (void* arg) {

	int  payload;
	double root;
	int id = (int)arg;

	while(1) {


		os_sem_wait(&con, 0xFFFF);
		// check whether N numbers are finished
		if (c >= (N-1)) {
			os_sem_send(&con);
			break;
		}
		
		c++;
		
		os_sem_send(&con);
		
		payload = retrieve();
		os_mut_wait(&print, 0xFFFF);
		root = sqrt(payload);
		//printf("c%d %d %d\n", id, c, payload); //used for debug only
		if (root == (int)root) {

			printf("c%d %d %d\n", id, payload, (int)root);

		}
		os_mut_release(&print);
		
		
	}
	os_mut_wait(&print, 0xFFFF);
	// get final time

	if (id == 0) {
		tb = os_time_get();
		
		printf("Execution Time: %.61f\n", (tb - ta) /100000.000000);
		
	}
	os_mut_release(&print);
	
	os_tsk_delete_self ();
	

	
}

__task void start(void) {
	
	int i;
	buffer.pIndex = 0;
	buffer.cIndex = 0;
	
	p = 0;
	c = 0;
	
	// initialize semaphores
	os_sem_init(&access, B);
	os_sem_init(&data, 0);
	os_sem_init(&lock, 1);
	os_sem_init(&prod, 1);
	os_sem_init(&con, 1);
	
	os_mut_init(&print);
	

	
	ta = os_time_get();

	// Create producer tasks
	for (i = 0; i < P; i++) {

		os_tsk_create_ex(producer, 1, (void*)i);
		
	}

	// Create consumer Tasks

	for (i = 0; i < C; i++) {

		os_tsk_create_ex(consumer, 1, (void*)i);
	}
	os_mut_release(&print);
	os_tsk_delete_self();
}


// Insert into buffer
void insert(int payload) {

	os_sem_wait(&access, 0xFFFF);
	os_sem_wait(&lock, 0xFFFF);
	
	buffer.buf[buffer.pIndex] = payload;
	buffer.pIndex = (buffer.pIndex + 1) % B;
	
	os_sem_send(&lock);
	os_sem_send(&data);
}


// remove from buffer
int retrieve() {	
	int payload;

	os_sem_wait(&data, 0xFFFF);
	os_sem_wait(&lock, 0xFFFF);
	
	payload = buffer.buf[buffer.cIndex];
	buffer.cIndex = (buffer.cIndex + 1) % B;
	
	os_sem_send(&lock);
	os_sem_send(&access);
	return payload;


}

int main (void) {
	
	SystemInit();
	uart0_init();
	
	os_sys_init(start);
	
	
	
}
