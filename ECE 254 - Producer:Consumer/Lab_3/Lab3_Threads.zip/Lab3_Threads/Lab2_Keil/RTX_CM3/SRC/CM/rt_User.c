
#include "rt_TypeDef.h"
#include "RTX_Config.h"
#include "rt_System.h"
#include "rt_Task.h"
#include "rt_List.h"
#include "rt_MemBox.h"
#include "rt_Robin.h"
#include "rt_HAL_CM.h"
#include "rt_User.h"

struct OS_XCB  my_mem_list;

int __initializeList(){
	my_mem_list.cb_type = HCB;
  my_mem_list.p_dlnk  = NULL;
  my_mem_list.p_blnk  = NULL;
  my_mem_list.delta_time = 0;
	return 0;
	
}
	

 /* Set up delay list: initially empty 
  my_mem_list.cb_type = HCB;
  my_mem_list.p_dlnk  = NULL;
  my_mem_list.p_blnk  = NULL;
  my_mem_list.delta_time = 0;
*/

/* os_tsk_count_get function*/
int rt_tsk_count_get(void) {
	unsigned int i;
	P_TCB task;
	unsigned int count = 0;
	
	for(i = 1; i <= os_maxtaskrun ; i++) {
		if(os_active_TCB[i-1] != NULL) {
			task = os_active_TCB[i-1];
			if(task->state != INACTIVE) {
				count++;
			}
		}
	}
	if(os_idle_TCB.state != INACTIVE) count++;
	return count;
}


/* os_tsk_get function*/
OS_RESULT rt_tsk_get(OS_TID task_id, RL_TASK_INFO * buffer) {
	
	P_TCB p_task;
	U32 size, current;
	
	/* Find the task in the "os_active_TCB" array. */
  if (task_id > os_maxtaskrun || os_active_TCB[task_id-1] == NULL) {
    /* Task with "task_id" not found or not started. */
    return (OS_R_NOK);
  }
	p_task = (P_TCB)os_active_TCB[task_id-1];
	
	buffer->state = p_task->state; 							// Task state
	buffer->prio = p_task->prio;								// Execution priority
	buffer->task_id = p_task->task_id;					// Task ID value for optimized TCB access
	buffer->ptask = p_task->ptask;							// Task entry address
	
	
	// Stack usage percent value. eg. =58 if 58%
	if(p_task->state == RUNNING){
		current = (U32) rt_get_PSP ();
	}else{
		current = (U32) p_task->tsk_stack;
	}	
	size = (U16)os_stackinfo;
	buffer->stack_usage = (size - (current - (U32) p_task->stack)) * 100 / size;
	
	
	return OS_R_OK;
}


// os_mem_alloc function
void * rt_mem_alloc(void * box_mem) {
	void * pointer;
	pointer = rt_alloc_box(box_mem);
	
	if(pointer == NULL){
		rt_put_prio (&my_mem_list, os_tsk.run);
		rt_block(0xffff, WAIT_MEM);
		return NULL;
	}else {
		return pointer;
	}
}


//os_mem_free function
OS_RESULT rt_mem_free(void * box_mem, void * box) {
	P_TCB tsb;
	if(my_mem_list.p_lnk!=NULL){
		tsb=rt_get_first(&my_mem_list);
		if(tsb!=NULL){
			tsb->ret_val = (U32) box;
			rt_dispatch(tsb);
			return OS_R_OK;
		}	else{
			return OS_R_NOK;
		}
	}else{	
		rt_free_box( box_mem, box);
		
		return OS_R_OK;
	}
}
