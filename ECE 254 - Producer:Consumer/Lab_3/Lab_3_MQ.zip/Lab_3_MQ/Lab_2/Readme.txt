Lab0B Information:

Files:

a. helloworld_rtxlib.uvmpw -->This is the multiproject workspace for the HelloWorld and RTX_CM3 projects
b. HelloWorld-->This is the application to be run on the board (Keil project)
c. RTX_CM3-->The custom kernel project with the modified library (Keil project)


Modifications:

To see the modifications we made, look in the following places:

-For the modifications in the Kernel, look in RTX_CM3\SRC\CM\rt_Task.c (the rt_tsk_count_get function 
starts at Line 37)

-For the modifications in the RTL.h, look in RTX_CM3\INC\RTL.h (Line 355-357)

-For the modifications in the console app, look in HelloWorld\helloworld.c
