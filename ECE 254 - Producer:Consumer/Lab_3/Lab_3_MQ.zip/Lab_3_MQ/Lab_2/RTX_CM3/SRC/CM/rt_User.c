#include "rt_TypeDef.h"
#include "RTX_Config.h"
#include "rt_System.h"
#include "rt_Task.h"
#include "rt_List.h"
#include "rt_MemBox.h"
#include "rt_Robin.h"
#include "rt_HAL_CM.h"
#include "rt_User.h"


//---------User Defined Functions-----------------------\\
	
	struct OS_XCB mymemlist;

OS_RESULT rt_tsk_get (OS_TID task_id, RL_TASK_INFO *buffer) {
	P_TCB current_task;
	double start, cur, sp, size;
	
	buffer->task_id = task_id;

	if (task_id == 0 || task_id == os_tsk.run->task_id) {
		current_task = os_tsk.run;
		cur = rt_get_PSP();		
	}
	else {
		if(task_id > os_maxtaskrun || os_active_TCB[task_id-1] == NULL) {
			return (OS_R_NOK);
		}
		current_task = os_active_TCB[task_id -1];
		cur = current_task->tsk_stack;
	}
	size = (U16)os_stackinfo;
	//get the starting address
	start = (U32)current_task->stack;
	
		 current_task = os_active_TCB[task_id - 1];
		 buffer->state = current_task->state;
		 buffer->prio = current_task->prio;
		 buffer->ptask = current_task->ptask;
		 buffer->stack_usage = 100 - ((cur - start)/size)*100;
	
	return (OS_R_OK);	
	
}
void *rt_mem_alloc (void *box_mem) {
	void * ptr ;
	ptr = rt_alloc_box(box_mem);
	if (ptr == NULL) {
		rt_put_prio((P_XCB)&mymemlist, os_tsk.run);
		rt_block(0xffff,WAIT_MEM);
	} else {
		return ptr;
	}
}
OS_RESULT rt_mem_free (void *box_mem, void *box) {
	P_TCB waitingtsk;
	int free;
	
	if(mymemlist.p_lnk == NULL) {
		free = rt_free_box(box_mem,box);
		if(free==0){
			return (OS_R_OK);
		}else {
			return (OS_R_NOK);
		}
	}

		waitingtsk = rt_get_first((P_XCB)(&mymemlist));
	if (waitingtsk != NULL) {
		waitingtsk->ret_val = (U32)box;
		rt_dispatch(waitingtsk);
		return (OS_R_OK);
	} else {
		free = rt_free_box(box_mem,box);
		if (free== 0) {
			return (OS_R_OK);
		}else{ 
			return (OS_R_NOK);
		}
	}
}

void rt_user_sys_init() {	
	mymemlist.cb_type = HCB;
  mymemlist.p_dlnk  = NULL;
  mymemlist.p_blnk  = NULL;
  mymemlist.delta_time = 0;
}
