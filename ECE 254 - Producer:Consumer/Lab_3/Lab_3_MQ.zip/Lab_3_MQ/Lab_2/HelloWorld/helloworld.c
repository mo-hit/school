/**
* @file: helloworld.c
* @brief: Two simple tasks running pseduo-parallelly
*/
#include <LPC17xx.h>
#include "../RTX_CM3/INC/RTL.h"
#include <stdio.h>
#include "uart_polling.h"

__task void taskCount()
{


	for(;;)
	{
		int value = os_tsk_count_get();
	printf("Tasks: %i\n", value);
		os_dly_wait(500);
	}
	




}
__task void task1()
{
	int i;
	for(i = 0; i<5; i++)
	{
	printf("Task1\n");
	os_dly_wait(499);
		
	}
	os_tsk_delete_self();

}
__task void task2()
{
	int i;
	for(i = 0; i<4; i++)
	{
	printf("Task2\n");
	os_dly_wait(499);
		
	}

os_tsk_delete_self();

}
__task void task3()
{
int i;
	for(i = 0; i<3; i++)
	{
	printf("Task3\n");
	os_dly_wait(499);
		
	}
os_tsk_delete_self();

}
__task void task4()
{
	int i;
	for(i = 0; i<2; i++)
	{
	printf("Task4\n");
	os_dly_wait(499);
		
	}

os_tsk_delete_self();

}

__task void init(void)
{


	os_tsk_create(taskCount, 1); // taskCount at priority 1

	
 	os_tsk_create(task1, 1); 
	os_tsk_create(task2, 1);
	os_tsk_create(task3, 1);
	os_tsk_create(task4, 1);



os_tsk_delete_self(); // must delete itself before exiting

}
int main ()
{
	
SystemInit();
uart0_init();
os_sys_init(init);

}
