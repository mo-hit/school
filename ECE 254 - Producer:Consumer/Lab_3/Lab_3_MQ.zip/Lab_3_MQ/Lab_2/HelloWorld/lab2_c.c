#include <LPC17xx.H>
#include "uart_polling.h"
#include "../RTX_CM3/INC/RTL.h"                      /* RTX kernel functions & defines      */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

OS_TID tsk1,tsk2;                          /* assigned identification for task 1  */
OS_TID g_tid = 255;
OS_MUT print;
OS_MUT last;
OS_MUT delay;


typedef struct {                      /* Message object structure            */
	int message;
} MSG;

int i = 0;
int j = 0;
int x;
int placeholder;

const int N = 398;
const int B = 8;
const int P = 1;
const int C = 3;

int ta,tb;

//flag for intialization to be performed in first producer
int first_flag = 1;

int p; //producer counter
int c; //consumer counter

int consumers_finished =0; //number of consumers finished
os_mbx_declare (mayconsume, B);
_declare_box (mpool,sizeof(MSG),N);/* Dynamic memory pool                */

__task void produce (void);
__task void consume (void);

__task void produce(void) {
	MSG *mptr;
	int payload;
	//printf("in producer\n");

	//only do on the first time
	if (first_flag == 1) {
		os_mbx_init (mayconsume, sizeof(mayconsume));
		os_mut_init(&print);
		os_mut_init(&last);
		os_mut_init(&delay);
		
		os_mut_wait(&delay,0xFFFF);
		
		payload = 0;
		p = 0;
		first_flag = 0;
	}
	
	payload = p;
	p++;
	
	
	
	
	while (i < N) {
		mptr = _alloc_box(mpool);
		mptr->message = payload;
		os_mbx_send (mayconsume,mptr,0xffff);
// 		os_mut_wait(&print,0xffff);
// 		printf("%d is produced by producer %d \n",(int)mptr->message, (p-1));
// 		os_mut_release(&print);
		i++;
		payload = payload + p;
	}
	os_tsk_delete_self();
}

__task void consume(void) {
	MSG *mptr;
	int num;
	int payload;
	double root;
	c++;
	//printf("in consumer\n");
	if (c == C) {
		num = N - ((N/C)*(C-1));
	} else {
		num = N/C;
		
	}
	
	
		while(j<num) {
			os_mbx_wait (mayconsume, (void **)&mptr, 0xffff); /* wait for the message    */
			os_mut_wait(&print,0xffff);
			payload = mptr->message;
// 			printf("%d is consumed by consumer %d\n",payload, (c-1));
			root = sqrt(payload);
			if ((int)root == root){
				printf("c%d %d %d \n", (c-1),payload,(int)root);
			}
			os_mut_release(&print);
				_free_box (mpool, mptr);           /* free memory allocated for message  */
			j++;
				
		}
		
		os_mut_wait(&last,0xffff);
		consumers_finished++;
		os_mut_release(&last);
		//if all consumers finished.....
		if (consumers_finished == C) {
			tb = os_time_get();
			printf("Execution Time: %.61f\n",(tb-ta)/100000.0000000);
		}

}

__task void start(void) {
	int i;
	ta = os_time_get();
	
	for(i=0;i<P;i++) {
		os_tsk_create(produce,1);
	}
	for(i=0;i<C;i++) {
		os_tsk_create(consume, 1);
	}
	os_dly_wait(5);
	os_tsk_delete_self();
}

int main(void) {
	SystemInit();         /* initialize the LPC17xx MCU */
	uart0_init();         /* initilize the first UART */
	printf("START\n");
	_init_box (mpool,sizeof(mpool), sizeof(MSG));
	printf("INITBOX\n");
	

	os_sys_init(start);
	
}